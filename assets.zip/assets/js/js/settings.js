﻿var BookIt = BookIt || {};
BookIt.Settings = BookIt.Settings || {};
BookIt.Settings.jyostarUrl = "http://jyostar.com/star/videoadmin/Appusers.php"; //"http://127.0.0.1:30000/api/account/register";
